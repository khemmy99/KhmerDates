KCalendar - Khmer calendar and currency words for Excel and Word
=================================================================

INSTALL
  1. Close Excel and Word.
  2. Extract this zip to a folder (right-click > Extract All).
  3. Double-click Install.cmd.
  4. Open Excel or Word. The "Calendar" tab is on the ribbon.

  Installs for the current Windows user only; administrator rights are not needed.
    Excel add-in   %APPDATA%\Microsoft\Templates\KCalendar.xlam
    Word template  %APPDATA%\Microsoft\Word\STARTUP\WKCalendar.dotm
    Font           Khmer OS Siemreap (only if it is not installed yet)
  Your Word location and digit setting are copied only if this PC has none yet.

REMOVE
  Close Excel and Word, then double-click Uninstall.cmd.

IF THE CALENDAR TAB DOES NOT APPEAR
  Excel: File > Options > Add-ins > Manage: Excel Add-ins > Go > Browse...
         and pick %APPDATA%\Microsoft\Templates\KCalendar.xlam
  Word:  File > Options > Add-ins > Manage: Templates > Go: tick WKCalendar.dotm
  If Office says macros are blocked: right-click the file > Properties > tick Unblock.

TRIAL AND LICENSE
  Free for 1 day (24 hours). Then a license is $2.5 for Excel and $2.5 for Word (one PC each).
  Calendar > ? (Help) > License > "Buy on Telegram" opens the bot @kcalendar88bot.
  Pay by bank QR and send the receipt; once approved, the add-in activates by itself.

FUNCTIONS IN EXCEL
  =KhmerDates(A1)        full Khmer lunar date
  =KhmerCurrency(A1)     amount in Khmer words, riel  (e.g. 2500000000 -> ពីរប៊ីលាន ប្រាំរយលានរៀលគត់)
  =DollarsCurrency(A1)   amount in Khmer words, US dollars

ការដំឡើង
  ១. បិទ Excel និង Word
  ២. ពន្លា zip នេះ (Right-click > Extract All)
  ៣. ចុចពីរដងលើ Install.cmd
  ៤. បើក Excel ឬ Word — ផ្ទាំង Calendar នៅលើ Ribbon

អាជ្ញាប័ណ្ណ
  សាកល្បងឥតគិតថ្លៃ ១ ថ្ងៃ (២៤ ម៉ោង)។ បន្ទាប់មក $2.5 សម្រាប់ Excel និង $2.5 សម្រាប់ Word (កុំព្យូទ័រ ១ គ្រឿង)។
  ប្រតិទិន > ? (ជំនួយ) > អាជ្ញាប័ណ្ណ > «ទិញតាម Telegram» ➜ @kcalendar88bot
  បង់តាម QR ធនាគារ ហើយផ្ញើបង្កាន់ដៃ — ពេលអនុម័ត នឹងសកម្មដោយស្វ័យប្រវត្តិ។
