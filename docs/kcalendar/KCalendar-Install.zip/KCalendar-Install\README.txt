KCalendar - Khmer calendar and currency words for Excel and Word
=================================================================

INSTALL
  1. Close Excel and Word.
  2. Extract this zip to a folder (right-click > Extract All).
  3. Double-click Install.cmd.
  4. Open Excel or Word. The "Calendar" tab is on the ribbon.

  Installs for the current Windows user only; administrator rights are not needed.
    Excel add-in   %APPDATA%\Microsoft\Templates\KCalendar.xlam
    Word template  %APPDATA%\Microsoft\Word\STARTUP\WKCalendar.dotm
    Font           Khmer OS Siemreap (only if it is not installed yet)
  Your Word location and digit setting are copied only if this PC has none yet.

REMOVE
  Close Excel and Word, then double-click Uninstall.cmd.

IF THE CALENDAR TAB DOES NOT APPEAR
  Excel: File > Options > Add-ins > Manage: Excel Add-ins > Go > Browse...
         and pick %APPDATA%\Microsoft\Templates\KCalendar.xlam
  Word:  File > Options > Add-ins > Manage: Templates > Go: tick WKCalendar.dotm
  If Office says macros are blocked: right-click the file > Properties > tick Unblock.

FUNCTIONS IN EXCEL
  =KhmerDates(A1)        full Khmer lunar date
  =KhmerCurrency(A1)     amount in Khmer words, riel  (e.g. 2500000000 -> ពីរប៊ីលាន ប្រាំរយលានរៀលគត់)
  =DollarsCurrency(A1)   amount in Khmer words, US dollars

ការដំឡើង
  ១. បិទ Excel និង Word
  ២. ពន្លា zip នេះ (Right-click > Extract All)
  ៣. ចុចពីរដងលើ Install.cmd
  ៤. បើក Excel ឬ Word — ផ្ទាំង Calendar នៅលើ Ribbon
