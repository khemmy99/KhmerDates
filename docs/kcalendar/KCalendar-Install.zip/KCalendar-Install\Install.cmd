@echo off
rem Double-click to install KCalendar for Excel and Word (current user, no admin needed).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
echo.
pause
