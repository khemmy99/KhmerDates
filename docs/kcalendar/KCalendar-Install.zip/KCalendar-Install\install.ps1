# KCalendar installer: Khmer calendar + currency words for Excel and Word.
# Installs for the current Windows user only; no administrator rights needed.
#   Excel  ->  %APPDATA%\Microsoft\Templates\KCalendar.xlam   (registered as an add-in)
#   Word   ->  %APPDATA%\Microsoft\Word\STARTUP\WKCalendar.dotm
#   Font   ->  Khmer OS Siemreap, if it is not installed yet
# -TestRoot redirects every folder and registry write (used to test this script).
param([string]$TestRoot = "")

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

if ($TestRoot) {
    $appData = Join-Path $TestRoot "AppData\Roaming"
    $localAppData = Join-Path $TestRoot "AppData\Local"
    $documents = Join-Path $TestRoot "Documents"
    $reg = "HKCU:\Software\KCalendarInstallTest"
} else {
    $appData = $env:APPDATA
    $localAppData = $env:LOCALAPPDATA
    $documents = [Environment]::GetFolderPath("MyDocuments")
    $reg = "HKCU:\Software"
}

function Say([string]$text, [string]$color = "Gray") { Write-Host $text -ForegroundColor $color }

Say ""
Say "KCalendar installer" "Cyan"
Say "-------------------" "Cyan"

if (-not $TestRoot -and (Get-Process EXCEL, WINWORD -ErrorAction SilentlyContinue)) {
    Say "Please close Excel and Word, then run Install.cmd again." "Yellow"
    exit 1
}

# Files from a downloaded zip carry the internet mark; Office would block their macros.
Get-ChildItem $here -Recurse -File | Unblock-File

# --- Excel add-in -------------------------------------------------------------
$templates = Join-Path $appData "Microsoft\Templates"
New-Item -ItemType Directory -Force $templates | Out-Null
$xlam = Join-Path $templates "KCalendar.xlam"
Copy-Item (Join-Path $here "KCalendar.xlam") $xlam -Force
Say "Excel add-in copied to $xlam"

# Register it so Excel opens it at start-up (Options\OPEN, OPEN1, ...).
$officeVersions = @(Get-ChildItem "$reg\Microsoft\Office" -ErrorAction SilentlyContinue |
    Where-Object { $_.PSChildName -match '^\d+\.\d+$' -and (Test-Path "$($_.PSPath)\Excel") } |
    Sort-Object { [double]$_.PSChildName } -Descending)
$version = if ($officeVersions.Count) { $officeVersions[0].PSChildName } else { "16.0" }
$options = "$reg\Microsoft\Office\$version\Excel\Options"
if (-not (Test-Path $options)) { New-Item -Path $options -Force | Out-Null }   # create only; never recreate an existing key

$existing = (Get-ItemProperty $options).PSObject.Properties | Where-Object { $_.Name -match '^OPEN\d*$' }
$entry = $existing | Where-Object { [string]$_.Value -match 'KCalendar\.xlam' } | Select-Object -First 1
if ($entry) {
    Set-ItemProperty $options $entry.Name ('"' + $xlam + '"')
    Say "Excel add-in already registered ($($entry.Name)); path updated"
} else {
    $name = "OPEN"; $n = 0
    while ($existing.Name -contains $name) { $n++; $name = "OPEN$n" }
    Set-ItemProperty $options $name ('"' + $xlam + '"')
    Say "Excel add-in registered (Office $version, $name)"
}

# --- Word template ------------------------------------------------------------
$startup = Join-Path $appData "Microsoft\Word\STARTUP"
New-Item -ItemType Directory -Force $startup | Out-Null
Copy-Item (Join-Path $here "WKCalendar.dotm") (Join-Path $startup "WKCalendar.dotm") -Force
Say "Word template copied to $startup"

# --- Font ---------------------------------------------------------------------
$fontName = "Khmer OS Siemreap (TrueType)"
$fontsKey = "$reg\Microsoft\Windows NT\CurrentVersion\Fonts"
$machineHas = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts" -ErrorAction SilentlyContinue).$fontName
$userHas = (Get-ItemProperty $fontsKey -ErrorAction SilentlyContinue).$fontName
if ($machineHas -or $userHas) {
    Say "Font Khmer OS Siemreap already installed"
} else {
    $fontDir = Join-Path $localAppData "Microsoft\Windows\Fonts"
    New-Item -ItemType Directory -Force $fontDir | Out-Null
    $fontFile = Join-Path $fontDir "KhmerOSsiemreap.ttf"
    Copy-Item (Join-Path $here "KhmerOSsiemreap.ttf") $fontFile -Force
    if (-not (Test-Path $fontsKey)) { New-Item -Path $fontsKey -Force | Out-Null }
    Set-ItemProperty $fontsKey $fontName $fontFile
    Say "Font Khmer OS Siemreap installed for this user"
}

# --- Settings from the original PC (only where none exist yet) ----------------
$settings = Join-Path $here "settings"
$locFile = Join-Path $documents "KWCalendarLocation.txt"
if ((Test-Path (Join-Path $settings "KWCalendarLocation.txt")) -and -not (Test-Path $locFile)) {
    New-Item -ItemType Directory -Force $documents | Out-Null
    Copy-Item (Join-Path $settings "KWCalendarLocation.txt") $locFile
    Say "Word location copied"
}
$wordKey = "$reg\VB and VBA Program Settings\KCalendar\Word"
$wordFile = Join-Path $settings "word-settings.txt"
if ((Test-Path $wordFile) -and -not (Test-Path $wordKey)) {
    New-Item -Path $wordKey -Force | Out-Null
    foreach ($line in Get-Content $wordFile) {
        if ($line -match '^(\w+)=(.*)$') { Set-ItemProperty $wordKey $Matches[1] $Matches[2] }
    }
    Say "Word calendar settings copied"
}

Say ""
Say "Done. Open Excel or Word: the Calendar tab is on the ribbon." "Green"
