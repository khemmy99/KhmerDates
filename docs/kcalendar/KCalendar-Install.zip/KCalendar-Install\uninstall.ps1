# KCalendar uninstaller: removes the Excel add-in and the Word template for
# the current user. The font and your saved settings are left in place.
param([string]$TestRoot = "")

$ErrorActionPreference = "Stop"
if ($TestRoot) {
    $appData = Join-Path $TestRoot "AppData\Roaming"
    $reg = "HKCU:\Software\KCalendarInstallTest"
} else {
    $appData = $env:APPDATA
    $reg = "HKCU:\Software"
}

if (-not $TestRoot -and (Get-Process EXCEL, WINWORD -ErrorAction SilentlyContinue)) {
    Write-Host "Please close Excel and Word, then run Uninstall.cmd again." -ForegroundColor Yellow
    exit 1
}

foreach ($f in (Join-Path $appData "Microsoft\Templates\KCalendar.xlam"),
               (Join-Path $appData "Microsoft\Word\STARTUP\WKCalendar.dotm")) {
    if (Test-Path $f) { Remove-Item $f -Force; Write-Host "Removed $f" }
}

# Remove the Excel start-up entry that points at KCalendar.xlam
Get-ChildItem "$reg\Microsoft\Office" -ErrorAction SilentlyContinue | ForEach-Object {
    $options = "$($_.PSPath)\Excel\Options"
    if (Test-Path $options) {
        (Get-ItemProperty $options).PSObject.Properties |
            Where-Object { $_.Name -match '^OPEN\d*$' -and [string]$_.Value -match 'KCalendar\.xlam' } |
            ForEach-Object { Remove-ItemProperty $options $_.Name; Write-Host "Excel add-in entry $($_.Name) removed" }
    }
}

Write-Host ""
Write-Host "KCalendar removed." -ForegroundColor Green
