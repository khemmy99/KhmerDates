@echo off
rem Double-click to remove KCalendar from Excel and Word.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
echo.
pause
