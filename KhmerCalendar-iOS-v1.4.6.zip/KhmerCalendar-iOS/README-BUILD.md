# Khmer Calendar (ប្រតិទិនខ្មែរ) — iOS build

Capacitor 8 iOS project, version **1.4.6** (build 50), bundle ID `com.khmercalendar.app`.

Dependencies use **Swift Package Manager**, so CocoaPods is *not* required.

## Install on your iPhone

1. Unzip this archive on the Mac.
2. Open **`ios/App/App.xcodeproj`** in Xcode.
   (There is no `.xcworkspace` — SPM projects don't use one.)
3. Wait for Xcode to finish "Resolving Package Versions". The first resolve needs
   internet: it fetches `capacitor-swift-pm` 8.3.4 from GitHub. The four plugins
   resolve locally from the bundled `node_modules/@capacitor/`.
4. Select the **App** target → **Signing & Capabilities**:
   - Tick **Automatically manage signing**
   - Pick your Apple ID under **Team** (add it via Xcode → Settings → Accounts)
   - If the bundle ID is taken, change it to something unique, e.g.
     `com.yourname.khmercalendar`
5. Plug in the iPhone, select it as the run destination, press **▶ Run**.
6. First launch on the phone: **Settings → General → VPN & Device Management →**
   trust your developer certificate, then reopen the app.

## Notes

- A free (non-paid) Apple Developer account signs the app for **7 days**; after that
  re-run from Xcode to reinstall. A paid account extends this to 1 year.
- Minimum iOS version is **15.0**.
- The app asks for location only to show local weather
  (`NSLocationWhenInUseUsageDescription`). Everything else works offline.

## Re-syncing web changes

The web app lives in `www/`. After editing it:

```sh
npm install          # only needed once, restores the full toolchain
npx cap sync ios
```

`cap sync` rewrites `ios/App/CapApp-SPM/Package.swift`. That's fine on macOS.
(This file had to be hand-corrected when generated on Windows, because the
Capacitor CLI emitted Windows `\` path separators, which are escape sequences
in Swift and do not compile.)
